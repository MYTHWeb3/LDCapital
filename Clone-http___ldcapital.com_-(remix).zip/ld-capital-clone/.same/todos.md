# LD Capital Website Clone - Todo List

## Project Overview
Clone the LD Capital website (https://ldcap.com/) with pixel-perfect design matching.

## Completed Tasks ✅
- [x] Create Next.js project with shadcn/ui
- [x] Set up typography (serif fonts for headings)
- [x] Configure color scheme (black/white minimal design)
- [x] Add necessary fonts
- [x] Create navigation component with logo
- [x] Add menu items: HOME, GLANCE, PORTFOLIO, REPORTS, CONTACT, HIRING
- [x] Add social media icons (Twitter, Medium, LinkedIn)
- [x] Create hero section with main heading
- [x] Our Story section with company description
- [x] Vision section with goals and aspirations
- [x] Edge section with bullet points of competitive advantages
- [x] Portfolio sections with company grids
- [x] Reports section with featured report
- [x] Articles section with blog posts
- [x] Contact information section
- [x] Social media links in footer
- [x] Ensure responsive design
- [x] Version and deploy the completed website
- [x] Refactor navigation to have sidebar on left with only LD CAPITAL logo centered in header
- [x] Remove social media icons from left sidebar (kept in footer only)
- [x] Implement mobile vertical navigation with rotated text on left side
- [x] Add smooth scroll navigation functionality
- [x] Create hiring page with job listings and application process
- [x] Increase spacing between navigation buttons in mobile UI
- [x] Implement bidirectional navigation visibility (hidden on hero, visible from Our Story onward)

## Current Focus 🎯
- [ ] Fix active section highlighting:
  - Metaverse & Gamefi & NFT section → PORTFOLIO button larger and bold
  - REPORTS section → REPORTS button larger and bold
  - Footer/Contact section → CONTACT button larger and bold
- [ ] Update social media icons layout:
  - Desktop sidebar: horizontal layout (Twitter, Medium, LinkedIn)
  - Mobile sidebar: hide social media icons completely
  - Mobile footer: add horizontal social media icons (Twitter, Medium, LinkedIn)

## Previously Completed
- [x] Basic active section highlighting implementation
- [x] Social media icons moved to sidebar bottom
- [x] Intersection observers for section detection

## Enhancement Tasks 🚀
- [ ] Add real company logos instead of placeholder boxes
- [ ] Create individual pages for each portfolio category
- [ ] Add search functionality to filter portfolio companies
- [ ] Add loading states and micro-interactions
- [ ] Implement dark mode toggle
- [ ] Add portfolio company detail pages
