'use client';

import { Navigation, Sidebar } from '@/components/Navigation';
import { Footer } from '@/components/ContactSection';
import Link from 'next/link';

export default function HiringPage() {
  const jobOpenings = [
    {
      title: "Senior Investment Analyst",
      department: "Investment",
      location: "Singapore / Hong Kong",
      type: "Full-time",
      description: "We are seeking a Senior Investment Analyst to join our team and help identify promising crypto projects in DeFi, NFT, and Web3 sectors."
    },
    {
      title: "Blockchain Developer",
      department: "Technology",
      location: "Remote",
      type: "Full-time",
      description: "Join our technical team to build and maintain our investment infrastructure and tools for portfolio management."
    },
    {
      title: "Business Development Manager",
      department: "Business Development",
      location: "Singapore",
      type: "Full-time",
      description: "Lead partnership initiatives and expand our network within the crypto ecosystem across Asia-Pacific region."
    },
    {
      title: "Research Analyst",
      department: "Research",
      location: "Singapore / Remote",
      type: "Full-time",
      description: "Conduct in-depth research on emerging technologies, market trends, and investment opportunities in the crypto space."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Sidebar alwaysVisible={true} />
      <div className="ml-12 md:ml-48">
        <Navigation />
        <main className="container mx-auto px-6 py-12">
          {/* Header */}
          <div className="max-w-4xl mb-16">
            <h1 className="font-serif text-4xl md:text-6xl font-normal mb-6">
              Join Our Team
            </h1>
            <p className="text-lg leading-relaxed text-gray-700 mb-8">
              LD Capital is always looking for talented individuals who share our passion for
              the future of digital assets and blockchain technology. Join us in building the
              next generation of crypto investment infrastructure.
            </p>
            <Link
              href="/"
              className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
            >
              ← Back to Home
            </Link>
          </div>

          {/* Why Join Us */}
          <div className="max-w-4xl mb-16">
            <h2 className="font-serif text-2xl md:text-3xl font-normal mb-8">
              Why Join LD Capital?
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-medium text-lg mb-3">Global Impact</h3>
                <p className="text-sm leading-relaxed text-gray-700">
                  Work with leading crypto projects and shape the future of digital finance
                  across global markets.
                </p>
              </div>
              <div>
                <h3 className="font-medium text-lg mb-3">Learning & Growth</h3>
                <p className="text-sm leading-relaxed text-gray-700">
                  Continuous learning opportunities in the fast-evolving crypto and blockchain
                  ecosystem with industry experts.
                </p>
              </div>
              <div>
                <h3 className="font-medium text-lg mb-3">Innovation</h3>
                <p className="text-sm leading-relaxed text-gray-700">
                  Be at the forefront of technological innovation and contribute to
                  groundbreaking projects in Web3 and DeFi.
                </p>
              </div>
              <div>
                <h3 className="font-medium text-lg mb-3">Collaborative Culture</h3>
                <p className="text-sm leading-relaxed text-gray-700">
                  Work with a diverse, international team of professionals who are passionate
                  about crypto and blockchain technology.
                </p>
              </div>
            </div>
          </div>

          {/* Job Openings */}
          <div className="max-w-4xl mb-16">
            <h2 className="font-serif text-2xl md:text-3xl font-normal mb-8">
              Current Openings
            </h2>
            <div className="space-y-8">
              {jobOpenings.map((job, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                  <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-4">
                    <div>
                      <h3 className="font-medium text-xl mb-2">{job.title}</h3>
                      <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                        <span>{job.department}</span>
                        <span>•</span>
                        <span>{job.location}</span>
                        <span>•</span>
                        <span>{job.type}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm leading-relaxed text-gray-700 mb-4">
                    {job.description}
                  </p>
                  <button className="text-sm font-medium text-gray-900 hover:text-gray-600 transition-colors border border-gray-300 px-4 py-2 rounded hover:border-gray-400">
                    Apply Now
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Application Process */}
          <div className="max-w-4xl mb-16">
            <h2 className="font-serif text-2xl md:text-3xl font-normal mb-8">
              Application Process
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center mx-auto mb-4 text-lg font-medium">
                  1
                </div>
                <h3 className="font-medium mb-2">Submit Application</h3>
                <p className="text-sm text-gray-700">
                  Send your resume and cover letter to our HR team.
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center mx-auto mb-4 text-lg font-medium">
                  2
                </div>
                <h3 className="font-medium mb-2">Initial Interview</h3>
                <p className="text-sm text-gray-700">
                  Phone or video call with our team to discuss your background.
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center mx-auto mb-4 text-lg font-medium">
                  3
                </div>
                <h3 className="font-medium mb-2">Final Interview</h3>
                <p className="text-sm text-gray-700">
                  In-depth interview with team members and leadership.
                </p>
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div className="max-w-4xl">
            <h2 className="font-serif text-2xl md:text-3xl font-normal mb-8">
              Get in Touch
            </h2>
            <div className="bg-gray-50 p-8 rounded-lg">
              <p className="text-sm leading-relaxed mb-4">
                Interested in joining LD Capital? We'd love to hear from you. Send your resume
                and a brief introduction to our HR team.
              </p>
              <div className="space-y-2">
                <p className="text-sm">
                  <span className="font-medium">Email:</span>{" "}
                  <a href="mailto:careers@ldcap.com" className="hover:text-gray-600 transition-colors">
                    careers@ldcap.com
                  </a>
                </p>
                <p className="text-sm">
                  <span className="font-medium">Subject Line:</span> [Position Title] - [Your Name]
                </p>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    </div>
  );
}
