'use client';

import { Navigation, Sidebar } from '@/components/Navigation';
import { HeroSection } from '@/components/HeroSection';
import { OurStorySection } from '@/components/OurStorySection';
import { EdgeSection } from '@/components/EdgeSection';
import { PortfolioSection } from '@/components/PortfolioSection';
import { ReportsSection } from '@/components/ReportsSection';
import { ContactSection, Footer } from '@/components/ContactSection';
import { useState, useEffect } from 'react';

export default function Home() {
  const [sidebarVisible, setSidebarVisible] = useState(false);

  useEffect(() => {
    // Add a small delay to ensure page has loaded before setting up observer
    const timer = setTimeout(() => {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.target.id === 'hero-section') {
              // Hide navigation when hero section is significantly visible (scrolled back to top)
              if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
                setSidebarVisible(true);
              }
            } else if (entry.target.id === 'our-story') {
              // Show navigation when Our Story section comes into view
              if (entry.isIntersecting && entry.intersectionRatio > 0.3) {
                setSidebarVisible(true);
              }
              // Hide navigation when Our Story completely leaves view (scrolling back up)
              else if (!entry.isIntersecting && entry.boundingClientRect.top > 0) {
                setSidebarVisible(false);
              }
            }
          });
        },
        {
          threshold: [0, 0.3, 0.5, 1], // Multiple thresholds for better detection
          rootMargin: '-10% 0px -10% 0px'
        }
      );

      const heroSection = document.getElementById('hero-section');
      const ourStorySection = document.getElementById('our-story');

      if (heroSection) {
        observer.observe(heroSection);
      }
      if (ourStorySection) {
        observer.observe(ourStorySection);
      }

      return () => {
        if (heroSection) {
          observer.unobserve(heroSection);
        }
        if (ourStorySection) {
          observer.unobserve(ourStorySection);
        }
      };
    }, 300); // 300ms delay

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Sidebar isVisible={sidebarVisible} />
      <div className={`transition-all duration-700 ease-in-out ${
        sidebarVisible ? 'ml-12 md:ml-48' : 'ml-0'
      }`}>
        <Navigation />
        <main>
          <HeroSection />
          <OurStorySection />
          <EdgeSection />
          <PortfolioSection />
          <ReportsSection />
          <ContactSection />
        </main>
        <Footer />
      </div>
    </div>
  );
}
