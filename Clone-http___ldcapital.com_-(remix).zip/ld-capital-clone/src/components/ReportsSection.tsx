interface Article {
  title: string;
  date: string;
  excerpt: string;
  link?: string;
}

export function ReportsSection() {
  const articles: Article[] = [
    {
      title: "Stacks, layer2 network of Bitcoin",
      date: "May 19, 2023",
      excerpt: "Stacks is the most thriving in the Bitcoin second-layer network projects and is about to receive a significant update by the end of 2023."
    },
    {
      title: "When will the situation for NFTFi reverse, lacking new narratives and new funding?",
      date: "May 19, 2023",
      excerpt: "The current NFT market lacks new narratives and new capital inflows, and high transaction fees lead to a continuous shrinking of funds within the NFT ecosystem."
    },
    {
      title: "Enhancing Crypto Asset Management through the Lens of US Stock Index Returns",
      date: "May 19, 2023",
      excerpt: "In recent years, the traditional financial market has witnessed rapid growth in index-based products, such as ETFs, with Smart Beta ETFs exhibiting a higher inflow rate than regular index ETFs."
    },
    {
      title: "Stability and High Growth of LSD",
      date: "May 18, 2023",
      excerpt: "Due to the imminent Shanghai upgrade, we believe it is necessary to reassess the future development of the LSD track and its impact on the entire on-chain ecosystem in light of recent data changes."
    },
    {
      title: "In-depth interpretation of Grayscale Trust | Why can you buy Ethereum at half price? (2)",
      date: "May 9, 2023",
      excerpt: "In the second installment of this series, we will explore how to build an index enhancement strategy for ETHE."
    },
    {
      title: "In-depth interpretation of Grayscale Trust | Why you can buy Ethereum at half price?",
      date: "Apr 18, 2023",
      excerpt: "The Grayscale Trust shares, which still have a discount of about 50% compared to its net asset value (NAV), are particularly attractive."
    },
    {
      title: "Reviewing the Dangers and Opportunities In the USDC De-Peg Crisis",
      date: "Mar 31, 2023",
      excerpt: "This article will explore the performance of lending, trading protocols, and decentralized stablecoin systems that were most affected by the USDC de-peg crisis, as well as potential trading opportunities."
    },
    {
      title: "MakerDAO, Igniting the Spark to the all things to grow",
      date: "Mar 6, 2023",
      excerpt: "MakerDAO, one of the most long-standing and successful crypto projects in decentralized governance, development, and operations, has entered the Endgame Plan phase."
    },
    {
      title: "Decentralized Storage: Where Web 3.0 Meets Metaverse",
      date: "Oct 15, 2021",
      excerpt: "In the summer of 2021, a set of strange-looking figures composed of 10,000 irregular pixels suddenly became popular. What surprised the market was that any single of these figures could be sold in ETH that was worth tens of millions of dollars. Since..."
    },
    {
      title: "The Metaverse Overview: From the Past to the Future (Part 2)",
      date: "Aug 16, 2021",
      excerpt: "In the case of Roblox, one of the most important reasons why it has become the first Metaverse stock is that it provided the original Play to Earn economic incentive model, which allows the game to add profit expectations on top of simple enterta..."
    }
  ];

  return (
    <section id="reports" className="w-full py-12 md:py-16 bg-gray-50 lg:px-[4px]">
      <div className="container mx-auto px-6">
        <div className="space-y-16">
          {/* Reports */}
          <div>
            <h2 className="font-serif text-2xl md:text-3xl font-normal mb-8">
              REPORTS
            </h2>

            <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
              <h3 className="font-serif text-xl font-normal mb-3">
                How To Find Blue Chip Assets
              </h3>
              <p className="text-sm text-gray-600 mb-4">1st Edition, April 2022</p>
              <p className="text-sm leading-relaxed">
                2021 proved to be another big year for blockchain technology. Not only did we see
                the introduction of a variety of new cryptocurrencies, but we officially hit 70 million
                registered blockchain wallets. And while there was quite a bit of ebb and flow in
                terms of coin value, the explosion of NFTs proved the blockchain is anything but
                predictable. But what about 2022? Well, that's what we're going to discuss in this
                report. Below, you'll find a comprehensive list highlighting everything investors,
                developers, and blockchain-curious individuals need to know.
              </p>
            </div>
          </div>

          {/* Articles */}
          <div>
            <h2 className="font-serif text-2xl md:text-3xl font-normal mb-8">
              ARTICLES
            </h2>

            <div className="space-y-8">
              {articles.map((article, index) => (
                <div key={index} className="border-b border-gray-200 pb-6 last:border-b-0">
                  <h3 className="font-serif text-lg font-normal mb-2">
                    {article.title}
                  </h3>
                  <p className="text-sm text-gray-600 mb-3">{article.date}</p>
                  <p className="text-sm leading-relaxed text-gray-800">
                    {article.excerpt}
                  </p>
                  <p className="text-xs text-gray-500 mt-2">
                    Other version: [简体中文]
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
