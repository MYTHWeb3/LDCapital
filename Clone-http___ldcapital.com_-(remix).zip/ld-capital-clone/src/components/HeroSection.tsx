'use client';

export function HeroSection() {
  return (
    <section
      id="hero-section"
      className="w-full min-h-[80vh] flex flex-col items-center justify-start bg-white relative pt-12 md:pt-20 lg:pt-32"
    >
      {/* Logo (如需要可加回来) */}

      <h1 className="font-serif font-normal text-center px-4 text-[26px] leading-snug md:text-5xl md:leading-tight lg:text-[100px] lg:leading-[1.1] max-w-5xl my-[10px] py-[30px] lg:px-[0px]"
      >
     Redefine a Better World with Digital Economyy
      </h1>
    </section>
  );
}
