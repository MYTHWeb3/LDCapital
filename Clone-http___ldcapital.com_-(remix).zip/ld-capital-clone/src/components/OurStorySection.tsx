export function OurStorySection() {
  return (
    <section id="our-story" className="w-full py-12 md:py-16">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl text-[18px] leading-relaxed">
          <div className="space-y-12 lg:px-[4px]">
            <div>
              <h2 className="font-serif text-2xl md:text-3xl font-normal mb-6 lg:text-[24px]">
                Our Story
              </h2>
              <div className="space-y-4">
                <p>
                  LD Capital is a leading crypto fund in investment and trading in primary and
                  secondary markets, whose sub-funds include Beco Fund, FoF, hedge fund, Meta
                  Fund, etc.
                </p>
                <p>
                  Since its establishment in 2016, LD Capital has successively invested in more
                  than 300 enterprises. With a highly professional global team and unique industrial
                  resource advantages, LD Capital has laid its emphasis on offering superb services
                  after investments, aiming to support the project in enhancing its long-term value
                  and ecological investment throughout the life cycle.
                </p>
              </div>
            </div>

            <div>
              <h3 className="font-serif text-2xl md:text-3xl font-normal mb-6">
                Vision
              </h3>
              <div className="space-y-4">
                <p>
                  We yearn to be prosperous for more than 88 years, to invest in and serve
                  more than 500 killer projects, and to emerge as a global leading investor with
                  over US$100 billion crypto assets under management.
                </p>
                <p>
                  We seek to create positive impact and sustainable value around the globe by
                  offering life-cycle solutions via diverse strategies for a range of market
                  opportunities and competent infrastructure support.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
