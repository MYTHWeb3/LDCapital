'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

export function Navigation() {
  return (
    <header className="w-full py-8">
      <div className="container mx-auto px-6">
        <div className="flex justify-center">
          {/* Logo - Centered */}
          <Link href="/" className="flex items-center">
            <img
              src="https://ugc.same-assets.com/Bvg8sPP5U5kJu_d7z8XuiQwtzHco4m5q.svg"
              alt="LD CAPITAL"
              className="h-8"
            />
          </Link>
        </div>
      </div>
    </header>
  );
}

export function Sidebar({ alwaysVisible = false, isVisible: externalVisible }: { alwaysVisible?: boolean; isVisible?: boolean }) {
  const [activeSection, setActiveSection] = useState<string>('');

  // Use external visibility state if provided, otherwise default to hidden
  const isVisible = alwaysVisible || externalVisible || false;

  // Track active section for highlighting navigation
  useEffect(() => {
    if (!isVisible) return;

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
          const sectionId = entry.target.id;

          // Map sections to navigation buttons
          if (sectionId === 'our-story') {
            setActiveSection('glance');
          } else if (sectionId === 'portfolio') {
            setActiveSection('portfolio');
          } else if (sectionId === 'reports') {
            setActiveSection('reports');
          } else if (sectionId === 'contact') {
            setActiveSection('contact');
          }
        }
      });
    };

    const observer = new IntersectionObserver(observerCallback, {
      threshold: [0.5],
      rootMargin: '-20% 0px -20% 0px'
    });

    // Observe sections that should highlight navigation
    const sections = ['our-story', 'portfolio', 'reports', 'contact'];
    sections.forEach(id => {
      const element = document.getElementById(id);
      if (element) observer.observe(element);
    });

    return () => observer.disconnect();
  }, [isVisible]);

  const getNavLinkClass = (navItem: string) => {
    const baseClass = "block text-sm font-medium transition-all duration-300 scroll-smooth";
    const isActive = activeSection === navItem;

    if (isActive) {
      return `${baseClass} text-gray-900 font-bold text-lg transform scale-110`;
    }
    return `${baseClass} text-gray-500 hover:text-gray-700`;
  };

  const getMobileNavLinkClass = (navItem: string) => {
    const baseClass = "text-xs font-medium transition-all duration-300 transform -rotate-90 whitespace-nowrap scroll-smooth";
    const isActive = activeSection === navItem;

    if (isActive) {
      return `${baseClass} text-gray-900 font-bold text-sm scale-110`;
    }
    return `${baseClass} text-gray-500 hover:text-gray-700`;
  };

  if (!isVisible) {
    return null; // Completely hide the sidebar when not visible
  }

  return (
    <aside className="fixed left-0 top-0 h-full bg-white z-10 w-12 md:w-48 animate-in slide-in-from-left duration-700 flex flex-col">
      {/* Desktop Navigation Menu */}
      <nav className="space-y-8 py-12 px-8 hidden md:block flex-1">
        <Link
          href="/"
          className="block text-sm font-medium text-gray-900 hover:text-gray-600 transition-colors"
        >
          HOME
        </Link>
        <a
          href="#our-story"
          className={getNavLinkClass('glance')}
        >
          GLANCE
        </a>
        <a
          href="#portfolio"
          className={getNavLinkClass('portfolio')}
        >
          PORTFOLIO
        </a>
        <a
          href="#reports"
          className={getNavLinkClass('reports')}
        >
          REPORTS
        </a>
        <a
          href="#contact"
          className={getNavLinkClass('contact')}
        >
          CONTACT
        </a>
        <Link
          href="/hiring"
          className="block text-sm font-medium text-gray-500 hover:text-gray-700 transition-colors"
        >
          HIRING
        </Link>
      </nav>

      {/* Desktop Social Media Icons at Bottom - Horizontal */}
      <div className="hidden md:flex flex-row space-x-3 justify-center px-8 pb-8">
        <a
          href="https://twitter.com/LD_Capital"
          target="_blank"
          rel="noopener noreferrer"
          className="w-8 h-8 bg-black rounded-full flex items-center justify-center hover:bg-gray-800 transition-colors"
        >
          <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
            <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
          </svg>
        </a>
        <a
          href="https://medium.com/@LD_Capital"
          target="_blank"
          rel="noopener noreferrer"
          className="w-8 h-8 bg-black rounded-full flex items-center justify-center hover:bg-gray-800 transition-colors"
        >
          <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
            <path d="M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z"/>
          </svg>
        </a>
        <a
          href="https://linkedin.com/company/ldcapital"
          target="_blank"
          rel="noopener noreferrer"
          className="w-8 h-8 bg-black rounded-full flex items-center justify-center hover:bg-gray-800 transition-colors"
        >
          <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
          </svg>
        </a>
      </div>

      {/* Mobile Navigation Menu - Vertical text along left edge */}
      <nav className="md:hidden flex flex-col justify-center h-full w-full">
        <div className="flex flex-col space-y-20 items-center flex-1 justify-center">
          <Link
            href="/"
            className="text-xs font-medium text-gray-900 hover:text-gray-600 transition-colors transform -rotate-90 whitespace-nowrap"
          >
            HOME
          </Link>
          <a
            href="#our-story"
            className={getMobileNavLinkClass('glance')}
          >
            GLANCE
          </a>
          <a
            href="#portfolio"
            className={getMobileNavLinkClass('portfolio')}
          >
            PORTFOLIO
          </a>
          <a
            href="#reports"
            className={getMobileNavLinkClass('reports')}
          >
            REPORTS
          </a>
          <a
            href="#contact"
            className={getMobileNavLinkClass('contact')}
          >
            CONTACT
          </a>
          <Link
            href="/hiring"
            className="text-xs font-medium text-gray-500 hover:text-gray-700 transition-colors transform -rotate-90 whitespace-nowrap"
          >
            HIRING
          </Link>
        </div>

        {/* Mobile Social Media Icons - Hidden in sidebar, will be added to footer instead */}
      </nav>
    </aside>
  );
}
