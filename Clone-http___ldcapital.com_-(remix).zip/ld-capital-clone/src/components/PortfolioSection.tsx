interface CompanyLogo {
  name: string;
  url?: string;
}

interface PortfolioSectionProps {
  title: string;
  companies: CompanyLogo[];
}

function CompanyGrid({ companies }: { companies: CompanyLogo[] }) {
  const getLogoUrl = (name: string) => {
    // Simple mapping for some well-known logos
    const logoMap: Record<string, string> = {
      "Flow": "https://cryptologos.cc/logos/flow-flow-logo.png",
      "illuvium": "https://cryptologos.cc/logos/illuvium-ilv-logo.png",
      "Decentraland": "https://cryptologos.cc/logos/decentraland-mana-logo.png",
      "BigTime": "https://s2.coinmarketcap.com/static/img/coins/64x64/18640.png",
      "StarAtlas": "https://s2.coinmarketcap.com/static/img/coins/64x64/11212.png",
      "Efinity": "https://s2.coinmarketcap.com/static/img/coins/64x64/11702.png",
      "Koii": "https://s2.coinmarketcap.com/static/img/coins/64x64/19267.png",
      "Terra": "https://cryptologos.cc/logos/terra-luna-luna-logo.png",
      "Algorand": "https://cryptologos.cc/logos/algorand-algo-logo.png",
      "Avalanche": "https://cryptologos.cc/logos/avalanche-avax-logo.png",
      "Near": "https://cryptologos.cc/logos/near-protocol-near-logo.png",
      "Polygon": "https://cryptologos.cc/logos/polygon-matic-logo.png",
      "AAVE": "https://cryptologos.cc/logos/aave-aave-logo.png",
      "Compound": "https://cryptologos.cc/logos/compound-comp-logo.png",
      "Polkadot": "https://cryptologos.cc/logos/polkadot-new-dot-logo.png",
      "QTUM": "https://cryptologos.cc/logos/qtum-qtum-logo.png",
      "Eth": "https://cryptologos.cc/logos/ethereum-eth-logo.png",
      "Vechain": "https://cryptologos.cc/logos/vechain-vet-logo.png"
    };

    return logoMap[name] || `https://via.placeholder.com/64x64/4F46E5/FFFFFF?text=${name.slice(0,2)}`;
  };

  return (
    <div className="grid grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-6 md:gap-8">
      {companies.map((company, index) => (
        <div key={index} className="flex flex-col items-center space-y-2">
          <div className="w-12 h-12 md:w-16 md:h-16 bg-white rounded-lg flex items-center justify-center hover:shadow-md transition-all duration-200 border border-gray-100">
            <img
              src={getLogoUrl(company.name)}
              alt={company.name}
              className="w-8 h-8 md:w-10 md:h-10 object-contain"
            />
          </div>
          <span className="text-xs text-center leading-tight font-medium text-gray-700">
            {company.name}
          </span>
        </div>
      ))}
    </div>
  );
}

export function PortfolioSection() {
  const metaverseCompanies: CompanyLogo[] = [
    { name: "immutablex" }, { name: "Flow" }, { name: "illuvium" }, { name: "Decentraland" },
    { name: "BigTime" }, { name: "Wilderworld" }, { name: "StarAtlas" }, { name: "Efinity" },
    { name: "Realm" }, { name: "Koii" }, { name: "rndr" }, { name: "Terra" },
    { name: "Alienworlds" }, { name: "Metaoasis" }, { name: "DeRace" }, { name: "Anima" },
    { name: "Cradles" }, { name: "Chingari" }, { name: "Seascape" }, { name: "Space" },
    { name: "Colizeum" }, { name: "Rmrk" }, { name: "DarkFrontier" }, { name: "JamBB" },
    { name: "Themis" }, { name: "GoldFever" }, { name: "Amasa" }, { name: "Epik" },
    { name: "StarryNift" }, { name: "Dehorizon" }, { name: "Demole" }, { name: "ERTHA" },
    { name: "Avocado" }, { name: "Unix" }, { name: "GGG" }, { name: "OPGame" },
    { name: "Placewar" }, { name: "Basscube" }, { name: "Vorto" }, { name: "Xcad" },
    { name: "Alethea" }, { name: "Cometh" }, { name: "Sweet" }, { name: "Atta" },
    { name: "Calaxy" }, { name: "CrytoART" }, { name: "Doingud" }, { name: "Dropmints" },
    { name: "Joystream" }, { name: "Marblecards" }, { name: "Fragcolor" }, { name: "YouClout" },
    { name: "Yup" }, { name: "MintBase" }, { name: "Melos" }, { name: "Niftsy" },
    { name: "Whaleshark" }, { name: "Torum" }, { name: "NFT3" }, { name: "Pylons" },
    { name: "Sidusheroes" }, { name: "Tap fantasy" }, { name: "HeroesChained" }, { name: "Starly" },
    { name: "kingdomx" }, { name: "StarSharks" }, { name: "Corite" }, { name: "Tankwars" },
    { name: "Envelop" }, { name: "Mirror World" }, { name: "Show me" }, { name: "Curionft" },
    { name: "Stakes" }, { name: "Polemos" }, { name: "Arcade" }, { name: "Hubble" },
    { name: "Astra" }, { name: "Walken" }, { name: "Element Black" }, { name: "Salad" },
    { name: "Topdj" }, { name: "Magns" }
  ];

  const blockchainInfrastructure: CompanyLogo[] = [
    { name: "Mexc" }, { name: "KuCoin" }, { name: "TokenAscendEx" }, { name: "Token" },
    { name: "LBank" }, { name: "Vechain" }, { name: "Algorand" }, { name: "Assembly" },
    { name: "Avalanche" }, { name: "Mina" }, { name: "BYTOM" }, { name: "Eth" },
    { name: "Flare" }, { name: "GXchain" }, { name: "OasisLabs" }, { name: "Near" },
    { name: "QTUM" }, { name: "Bobq" }, { name: "Celer" }, { name: "Polygon" },
    { name: "BTCEX" }, { name: "Evanesco" }, { name: "Abcana" }, { name: "Sienna" },
    { name: "Agoric" }, { name: "NYM" }, { name: "Yellow" }, { name: "Shade" },
    { name: "Bitcoke" }
  ];

  const defiEco: CompanyLogo[] = [
    { name: "Qredo" }, { name: "DUET-PROTOCOL" }, { name: "AAVE" }, { name: "Coinlist" },
    { name: "DaoMaker" }, { name: "Republic" }, { name: "OpenOcean" }, { name: "CERTIK" },
    { name: "Teller" }, { name: "Compound" }, { name: "Index" }, { name: "Mobilecoin" },
    { name: "Impossible" }, { name: "Nsure-Network" }, { name: "CLEAR" }, { name: "SOLACE" },
    { name: "Strips" }, { name: "ATLAS-Finance" }, { name: "Dafi" }, { name: "Domination" },
    { name: "Hurricane" }, { name: "LEVANA" }, { name: "NearPad" }, { name: "Polystarter" },
    { name: "Clipper" }, { name: "Cboe" }, { name: "PowerPool" }, { name: "insureDAO" },
    { name: "Handle.fi" }, { name: "Titan" }, { name: "OpenLeverage" }, { name: "Pebble" },
    { name: "DefyTrends" }, { name: "Aperture" }, { name: "Soda" }
  ];

  const web3Companies: CompanyLogo[] = [
    { name: "Polkadot" }, { name: "REN" }, { name: "Ankr" }, { name: "BitDao" },
    { name: "Cere" }, { name: "DAOSquare" }, { name: "Litentry" }, { name: "Polkadex" },
    { name: "Reef" }, { name: "SubDao" }, { name: "Swing" }, { name: "Decentland" }
  ];

  const fofCompanies: CompanyLogo[] = [
    { name: "1kx" }, { name: "BigTime" }, { name: "DHVC" }, { name: "KraKen" },
    { name: "SHIMACap" }, { name: "Metaverse Alliance" }, { name: "StillWater" },
    { name: "CryptoBridge" }, { name: "Lightshift" }, { name: "Woodstock Fund" },
    { name: "Blockchainff" }, { name: "Republic" }
  ];

  return (
    <section id="portfolio" className="w-full py-12 md:py-16 lg:px-[4px]">
      <div className="container mx-auto px-6">
        <div className="space-y-16">
          {/* Metaverse & Gamefi & NFT */}
          <div>
            <h2 className="font-serif text-2xl md:text-3xl font-normal mb-8">
              Metaverse & Gamefi & NFT
            </h2>
            <CompanyGrid companies={metaverseCompanies} />
          </div>

          {/* Blockchain Infrastructure */}
          <div>
            <h2 className="font-serif text-2xl md:text-3xl font-normal mb-8">
              Blockchain Infrastructure
            </h2>
            <CompanyGrid companies={blockchainInfrastructure} />
          </div>

          {/* DeFi Eco */}
          <div>
            <h2 className="font-serif text-2xl md:text-3xl font-normal mb-8">
              DeFi Eco
            </h2>
            <CompanyGrid companies={defiEco} />
          </div>

          {/* Web3.0 */}
          <div>
            <h2 className="font-serif text-2xl md:text-3xl font-normal mb-8">
              Web3.0
            </h2>
            <CompanyGrid companies={web3Companies} />
          </div>

          {/* FOF */}
          <div>
            <h2 className="font-serif text-2xl md:text-3xl font-normal mb-8">
              FOF
            </h2>
            <CompanyGrid companies={fofCompanies} />
          </div>
        </div>
      </div>
    </section>
  );
}
